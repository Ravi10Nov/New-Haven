// const firebaseConfig = {
//   apiKey: process.env.REACT_APP_API_KEY,
//   authDomain: process.env.REACT_APP_AUTH_DOMAIN,
//   projectId: process.env.REACT_APP_PROJECT_ID,
//   storageBucket: process.env.REACT_APP_STORAGE_BUCKET,
//   messagingSenderId: process.env.REACT_APP_MESSAGING_SENDER_ID,
//   appId: process.env.REACT_APP_APP_ID,
// };
const firebaseConfig = {
  apiKey: "AIzaSyC10e9lOyR_sIvCEhTf6juVUOtOCcTyq7E",
  authDomain: "sotnac-28a4d.firebaseapp.com",
  projectId: "sotnac-28a4d",
  storageBucket: "sotnac-28a4d.appspot.com",
  messagingSenderId: "307978664296",
  appId: "1:307978664296:web:dc35be97a5d3b42199fedd"
};
export default firebaseConfig;