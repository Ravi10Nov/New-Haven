// import React from 'react';
// import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
// import VisibilityIcon from '@mui/icons-material/Visibility';
// import BorderColorIcon from '@mui/icons-material/BorderColor';
// import { NavLink } from 'react-router-dom';
// import './PageTitleTbody.css';

// const PageTitleTbody = ({ url }) => {
//     return (
//         <tbody>
//             <tr>
//                 <td>Home Page</td>
//                 <td>Admin</td>
//                 <td>
//                     <VisibilityIcon className='ico_color_suc'></VisibilityIcon>
//                     <NavLink to={`${url}/SitePagesWelcomeSection`}>
//                         <BorderColorIcon className='ico_color_pri c_ml_15'></BorderColorIcon>
//                     </NavLink>
//                     <DeleteOutlineIcon className='ico_color_danger c_ml_15'></DeleteOutlineIcon>
//                 </td>
//             </tr>
//             <tr>
//                 <td>Contact Page</td>
//                 <td>Admin</td>
//                 <td><VisibilityIcon className='ico_color_suc'></VisibilityIcon>
//                     <NavLink to={`${url}/SitePagesWelcomeSection`}>
//                         <BorderColorIcon className='ico_color_pri c_ml_15'></BorderColorIcon>
//                     </NavLink>
//                     <DeleteOutlineIcon className='ico_color_danger c_ml_15'></DeleteOutlineIcon></td>
//             </tr>
//             <tr>
//                 <td>FAQ Page</td>
//                 <td>Admin</td>
//                 <td><VisibilityIcon className='ico_color_suc'></VisibilityIcon>
//                     <NavLink to={`${url}/SitePagesWelcomeSection`}>
//                         <BorderColorIcon className='ico_color_pri c_ml_15'></BorderColorIcon>
//                     </NavLink>
//                     <DeleteOutlineIcon className='ico_color_danger c_ml_15'></DeleteOutlineIcon></td>
//             </tr>
//             <tr>
//                 <td>Authority Page</td>
//                 <td>Admin</td>
//                 <td><VisibilityIcon className='ico_color_suc'></VisibilityIcon>
//                     <NavLink to={`${url}/SitePagesWelcomeSection`}>
//                         <BorderColorIcon className='ico_color_pri c_ml_15'></BorderColorIcon>
//                     </NavLink>
//                     <DeleteOutlineIcon className='ico_color_danger c_ml_15'></DeleteOutlineIcon></td>
//             </tr>
//             <tr>
//                 <td>Constitution Page</td>
//                 <td>Admin</td>
//                 <td><VisibilityIcon className='ico_color_suc'></VisibilityIcon>
//                     <NavLink to={`${url}/SitePagesWelcomeSection`}>
//                         <BorderColorIcon className='ico_color_pri c_ml_15'></BorderColorIcon>
//                     </NavLink>
//                     <DeleteOutlineIcon className='ico_color_danger c_ml_15'></DeleteOutlineIcon></td>
//             </tr>
//             <tr>
//                 <td>Rise of The Medical Epidemic Page</td>
//                 <td>Admin</td>
//                 <td><VisibilityIcon className='ico_color_suc'></VisibilityIcon>
//                     <NavLink to={`${url}/SitePagesWelcomeSection`}>
//                         <BorderColorIcon className='ico_color_pri c_ml_15'></BorderColorIcon>
//                     </NavLink>
//                     <DeleteOutlineIcon className='ico_color_danger c_ml_15'></DeleteOutlineIcon></td>
//             </tr>
//             <tr>
//                 <td>Ethical Code of Conduct Page</td>
//                 <td>Admin</td>
//                 <td><VisibilityIcon className='ico_color_suc'></VisibilityIcon>
//                     <NavLink to={`${url}/SitePagesWelcomeSection`}>
//                         <BorderColorIcon className='ico_color_pri c_ml_15'></BorderColorIcon>
//                     </NavLink>
//                     <DeleteOutlineIcon className='ico_color_danger c_ml_15'></DeleteOutlineIcon></td>
//             </tr>
//         </tbody>

//     );
// };

// export default PageTitleTbody;