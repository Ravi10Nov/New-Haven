import React from 'react';
import certificate from '../../assets/Adoption Certificate 2022.png';
import './certificate.css';
export default function Certificate() {
  return (
    <div className='certificate mt-3'>
      {/* <img src={certificate} alt='' /> */}
    </div>
  );
}
